<!doctype html>
<html class="no-js" lang="zxx">
<!-- serdkelaniya.com developed by Harshadeva Priyankara Bandara -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Serd Kelaniya</title>
    {{--<link rel="shortcut icon" type="image/x-icon" href="{{ URL::asset('my_assets/img/title.ico')}}" />--}}
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

