</head>

<body>

<!--[if lte IE 9]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
<![endif]-->

<div id="preloader">
    <div class="spinner">
         <img class="double-bounce1"  src="{{\Illuminate\Support\Facades\URL::asset('myAssets/images/loader.jpg')}}">
        <img class="double-bounce2"  src="{{\Illuminate\Support\Facades\URL::asset('myAssets/images/loader.jpg')}}">
    </div>
</div><!-- #preloader -->

<!-- demo color panel switch -->

<!-- header section -->
