<style>
    * {
        left: 0;
        line-height: 200px;
        position: absolute;
        text-align: center;
        top: 50%;
        width: 100%;
        color: #9c9da0
    }
    h1 {
        margin-top: -100px;
    }
    h2{
        margin-top: -150px;
    }
</style>
<h2 >404 | Not Found</h2>
<h1>{{__('common.notFoundText')}}</h1>